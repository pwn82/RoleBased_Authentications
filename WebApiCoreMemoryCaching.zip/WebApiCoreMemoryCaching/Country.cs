﻿namespace WebApiCoreMemoryCaching
{
    public class Country
    {
        public string Name { get; set; }
        public string Code { get; set; }
    }
}
