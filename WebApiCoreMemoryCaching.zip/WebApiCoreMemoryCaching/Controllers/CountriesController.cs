﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Newtonsoft.Json;


namespace WebApiCoreMemoryCaching.Controllers
{
    [Route("api/[controller]")]
    public class CountriesController : Controller
    {

        private readonly IMemoryCache _cache;
        public CountriesController(IMemoryCache memoryCache)
        {
            _cache = memoryCache;
        }

        [HttpGet("{countryCode}")]
        public async Task<IActionResult> Get(string countryCode)
        {
            string country = await LookupCountryByCode(countryCode);

            if (string.IsNullOrEmpty(country))
            {
                return NoContent();
            }
            return Ok(country);
        }

        private async Task<string> LookupCountryByCode(string countryCode)
        {
            if(!_cache.TryGetValue("ListOfCountries", out Dictionary<string, string> countries))
            {
                Console.WriteLine("Cache miss....loading from database into cache");
                countries =
                    JsonConvert.DeserializeObject<Dictionary<string, string>>(
                        await System.IO.File.ReadAllTextAsync("countrylist.json"));

                MemoryCacheEntryOptions options = new MemoryCacheEntryOptions
                {
                    AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(25), // cache will expire in 25 seconds
                    SlidingExpiration = TimeSpan.FromSeconds(5) // caceh will expire if inactive for 5 seconds
                };

                options.RegisterPostEvictionCallback(Callback,"Some state info");

                _cache.Set("ListOfCountries", countries, options);
            }
            else
            {
                Console.WriteLine("Cache hit");
            }

            return countries[countryCode];
        }

        private void Callback(object key, object value, EvictionReason reason, object state)
        {
            Console.WriteLine("Evicted");
        }
    }
}
