﻿using System;
using System.Data;
using System.Web.Caching;


public partial class DataCache : System.Web.UI.Page
{

    DataTable dtEmployee;
    protected void Page_Load(object sender, EventArgs e)
    {

        TimeSpan ts = new TimeSpan(0, 0, 10);
        //If cache has null, it will create two cache and it will bind into the gridview
        if (Cache["Employee"] == null)
        {
            dtEmployee = new DataTable("Employee");
            dtEmployee.Columns.Add("EmpID", typeof(int));
            dtEmployee.Columns.Add("EmpName", typeof(string));

            DataRow rs = dtEmployee.NewRow();
            rs[0] = 10;
            rs[1] = "Annathurai";
            dtEmployee.Rows.Add(rs);

            //To assign datatable to cache memory.
            Cache["Employee"] = dtEmployee;
            Cache.Insert("Employee", dtEmployee, null, Cache.NoAbsoluteExpiration, ts);

            Response.Write("Its processing with Database hit");
        }
        else
        {
            //If cache has value, It retrive from cache memory and bind into the gridview
            Response.Write("Its processing from cache");
        }

        //Here we are converting cache into datatable
        GridView1.DataSource = (DataTable)Cache["Employee"];
        GridView1.DataBind();

    }
}
